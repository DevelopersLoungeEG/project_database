<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<?php
function Redirect($url,$permanent=false){
    if(headers_sent()==false){
        header('Location:'.$url,true,($permanent===true)? 301:302);
    }
    exit();
}
  require 'dpconnect.php';  

    $uninum=$_POST['email'];
    $pass=$_POST['password'];
     $name=$_POST['name'];
     $city=$_POST['city'];
    $login='Log in';
    $b=false;
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $userexist="SELECT COUNT(email) as total
         FROM useraccount
         WHERE email='$uninum'";
         $usercheck=mysqli_query($conn,$userexist);
         $usercheck1=mysqli_fetch_assoc($usercheck);
         
         if($usercheck1['total']==0) {   
            $sql="INSERT INTO useraccount
            VALUES ('','$name','$uninum','$pass','$city')";
            mysqli_query($conn,$sql);
            $login=$name;
        }

         else  {
            $userexist="SELECT COUNT(email) as total
            FROM useraccount
            WHERE email='$uninum' AND password='$pass'";
            $usercheck=mysqli_query($conn,$userexist);
            $usercheck1=mysqli_fetch_assoc($usercheck);
            if($usercheck1['total']==0) {
             $response=array("type"=>"error","message"=>"Email already in use.");    
            }

            else { $response=array("type"=>"success","message"=>"you have loged in succesfully.");
               $userupdateprifile="UPDATE useraccount  set name='$name',city='$city'
               WHERE email='$uninum' AND password='$pass'";
               mysqli_query($conn,$userupdateprifile);
               $username="SELECT name
                 FROM useraccount
                 WHERE email='$uninum' AND password='$pass'";   
                 $usernamesql=mysqli_query($conn,$username);
                 $login=mysqli_fetch_array($usernamesql);
                $b=true;
            }
         }
    }
  
    mysqli_close($conn);
    if(!$b){
        header('Location: signup.php?user='.$response['message']);
        echo $response['message'];
       }
    if($b)
    header('Location: index.php?user='.$login[0]);
    ?> 

</body>
</html>