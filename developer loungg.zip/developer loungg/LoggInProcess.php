<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<?php
function Redirect($url,$permanent=false){
    if(headers_sent()==false){
        header('Location:'.$url,true,($permanent===true)? 301:302);
    }
    exit();
}

  require 'dpconnect.php';  

    $uninum=$_POST['email'];
    $pass=$_POST['password'];
    $login='Log in';

    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $userexist="SELECT COUNT(email) as total
         FROM useraccount
         WHERE email='$uninum'";
         $usercheck=mysqli_query($conn,$userexist);
         $usercheck1=mysqli_fetch_assoc($usercheck);
       
         if($usercheck1['total']==0) {   
           Redirect("signup.php",false);
        }
         else  {
            $userexist="SELECT COUNT(email) as total
            FROM useraccount
            WHERE email='$uninum' AND password='$pass'";
            $usercheck=mysqli_query($conn,$userexist);
            $usercheck1=mysqli_fetch_assoc($usercheck);
            if($usercheck1['total']==0) {
             $response=array("type"=>"error","message"=>"Email already in use.");
            
            }
            else { $response=array("type"=>"error","message"=>"you have loged in succesfully.");
                $sql1="SELECT name 
                FROM useraccount
                WHERE email='$uninum' AND password='$pass'"; 
                $username= mysqli_query($conn,$sql1); 
                $username1=mysqli_fetch_array($username);      
                     $login=$username1[0];   
            }
         }
    }
   
    //echo $response['message'];
    mysqli_close($conn);
    header('Location: index.php?user='.$login);
    ?> 

</body>
</html>