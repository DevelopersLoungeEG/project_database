<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>developers loung</title>
        <link rel="stylesheet"  href="pages/css/bootstrap.min.css">
        <link rel="stylesheet"  href="pages/css/animate.css">
        <link rel="stylesheet"  href="pages/css/hover.css">
        <link rel="stylesheet"  href="pages/css/font-awesome.min.css">
        <link rel="stylesheet"  href="pages/css/main.css">
    </head>
    <body>

        <!--Start UP-->
        <div class="up">
        <i class="fa fa-angle-double-up" aria-hidden="true"></i>
        </div>    
        <!--End Up-->

        <!-- start Navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark ">
            <a class="navbar-brand" href="#"><h6 class="hvr-bounce-in"><i class="fas fa-team"></i> Developers               <span>Lounge</span></h6> </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSup" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSup">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link hvr-pop" data-scroll="#home">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link hvr-pop" data-scroll="#about" >About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link hvr-pop" data-scroll="#service">services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link hvr-pop" data-scroll="#category">Our Teams</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link hvr-pop" data-scroll="#carousel">Testimonail</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link hvr-pop" data-scroll="#project">Projects</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link hvr-pop" href="signup.php">contact Us</a>
                    </li>
                </ul>

                <ul class="navbar-nav mr-auto">
                    <li class="nav-item hvr-pop log">
                        <i class="fa fa-user-circle" aria-hidden="true"></i>
                         <?php
                            if($_GET){
                           echo $_GET['user'];
                           if($_GET['user']=="Log in"){
                               echo "</br> <spam style='color:red;'>wrong email or password</spam>";
                           }
                            }
                            else{
                               // echo "log in";
                               // echo "email or password incorrect";
                            }
                            ?>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- end Navbar -->
        
        <!-- start login-popup -->
        <div class="popup">
            <div class="inner-popup">
                <div class="close-popup"><i class="fa fa-times" aria-hidden="true"></i></div>
                <form  method="post" action="LoggInProcess.php">
                    <div>
                        <i class="fa fa-user-circle fa-5x" aria-hidden="true"></i>
                    </div>
                    <div>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
                    </div>
                    <div >
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" maxlength="10" required>
                    </div>
                    <div>
                        <button type="submit"  onclick="valid()" class="btn btn-default btn-lg">log in</button>
                    </div>  
                </form>
            </div>
        </div>
        <!-- end login-popup -->

        <!-- start header -->
        <div id ="home" class="head scroll" style="height: 500px;overflow: hidden;">
            <img src="img/cover/apple-computer-decor-326502.jpg" style="height: 100%;width: 100%">
        </div>
        <!-- end header -->

        <!-- start about  -->
         <section id="about" class="sections about-us scroll" >
            <div class="container">
                <div class="section-header text-center">
                    <h2 class="section-title">About Us</h2>
                    <div class="line">
                        <span></span>
                    </div>
                    <p class="wow bounceInLeft" data-wow-offset="20" data-wow-delay="1.5s" data-wow-duration="2s">
                        A programming community which sells services for Web Development & Web Designing, Train, and hire people.
                    </p>
                    </div><!-- ./section-header -->

                    <div class="row">
                        <div class="col-md-6">
                            <div class="about-info wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                                <h3 class="mg_bt">Welcome to <span>DevelopersLounge.</span> Design Agency Thinking Creative</h3>
                                <p class="about-info-desc wow bounceInLeft">
                                    Hello. We are DevelopersLounge. A programming community which sells services for Web Developing & Web Designing, Train, and hire people. Also, We do have Projects & Templates that can be sold.
                                    What are you waiting for? Signup to Create an account and drop your opinion on your templated, give thumbsup, contact us or leave a message, etc.
                                    You May also Join our teams by creating an accont at (join us link)
                                    Choose the programming languages you know and you'll be assinged with the group and team that fits you, Good Luck.

                                    Sincerely, DevelopersLounge Family!
                                </p>

                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="about-img wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
                                <img src="img/cover/about-bg.jpg" width="100%" alt="">
                            </div>
                        </div>
                    </div>

                </div>
        </section>
        <!-- end about -->

        <!-- Services -->
        <section id="service" class="sections services scroll">
            <div class="container">
                <div class="section-header text-center">
                    <h2 class="section-title">Our Services</h2>
                    <div class="line">
                        <span></span>
                    </div>
                    <p>
                        These are some of the services we do, check them out!
                    </p>
                </div><!-- ./section-header -->

                <div class="row">
                    <div class="col-md-4  wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                        <div class="serv">
                            <i class="icon fa fa-camera fa-lg"></i>
                            <h3 class="serv-title">PhotoShop</h3>
                            <p class="serv-desc">
                                We have some <span style="font-weight: bold; color:red;">EXPERT</span> photo editors at creating logos, editing photos and creating templates.
                            </p>
                        </div>
                    </div><!-- ./serv -->

                    <div class="col-md-4 wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
                        <div class="serv">
                            <i class="icon fa fa-desktop fa-lg"></i>
                            <h3 class="serv-title">Web Designing</h3>
                            <p class="serv-desc">
                                We have some <span style="font-weight: bold; color:red;">EXPERT</span> Front-End Web Developers that are ready to do any task any time!
                            </p>
                        </div>
                    </div><!-- ./serv -->

                    <div class="col-md-4 wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility:         visible; animation-delay: 0.5s; animation-name: fadeInRight;">
                        <div class="serv">
                            <i class="icon fa fa-laptop fa-lg"></i>
                            <h3 class="serv-title">Web Development</h3>
                            <p class="serv-desc">
                                We have some <span style="font-weight: bold; color:red;">EXPERT</span> Back-End Web Developers that are ready to do any task any time!
                            </p>
                        </div>
                    </div><!-- ./serv -->
                </div><!-- ./row -->

                <div class="row">
                    <div class="col-md-4 wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                        <div class="serv">
                            <i class="icon fa fa-database fa-lg"></i>
                            <h3 class="serv-title">Marketing</h3>
                            <p class="serv-desc">
                                We're Currently looking for people who have experince in <span style="font-weight: bold; color:red;">Marketing!</span></p>
                        </div>
                    </div><!-- ./serv -->

                    <div class="col-md-4 wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                        <div class="serv">
                            <i class="icon fa fa-pencil fa-lg"></i>
                            <h3 class="serv-title">Innovation</h3>
                            <p class="serv-desc">
                                Our Main aim is to get all the developers on new level. All our work and projects are based on teamwork. We provide full <span style="font-weight: bold; color:red;">Innovation</span> for all the developers.
                            </p>
                        </div>
                    </div><!-- ./serv -->

                    <div class="col-md-4  wow fadeInRight animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
                        <div class="serv">
                            <i class="icon fa fa-file-video-o fa-lg"></i>
                            <h3 class="serv-title">Software Development</h3>
                            <p class="serv-desc">
                                We're Currently looking for <span style="font-weight: bold; color:red;">Software Developers</span>, However; we got some beginners who are learning how to deal with Softwares and stuff related to that.
                            </p>
                        </div>
                    </div><!-- ./serv -->
                </div><!-- ./row -->

            </div>
        </section>   
        <!-- Services -->   
        
        <!--start section our team-->
        <div id="category" class="our_team text-center scroll">
            <div class="team">
                <div class="container">
                    <h1>Meet Our Teams</h1>
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="person  wow pulse" data-wow-duration="1s">
                                <img class="rounded-circle" src="img/team/business-career-confidence-776615.jpg">
                                <h3 style="color:#ffd700;padding-top: 20px"> Designers </h3>
                                <h5>Front-End</h5>
                                <p class="lead">
                                    this team is responsible in designing websites, Softwares, and anything related to that
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="person  wow pulse" data-wow-duration="1s">
                                <img class="rounded-circle" src="img/team/american-colleagues-digital-device-1437540.jpg">
                                <h3 style="color:#ffd700;padding-top: 20px"> Developers </h3>
                                <h5>Back-end </h5>
                                <p class="lead">
                                    this team is resposible in creating databases for websites, softwares, anything realted to that
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="person  wow pulse" data-wow-duration="1s">
                                <img class="rounded-circle" src="img/team/backlit-bright-dawn-697243.jpg">
                                <h3 style="color:#ffd700;padding-top: 20px"> Marketing </h3>
                                <h5>Market</h5>
                                <p class="lead"> 
                                    this team is responsible in marketing your product and anything realted to that.
                                    (note: Vacant Position)
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="person  wow pulse" data-wow-duration="1s">
                                <img class="rounded-circle" src="img/team/american-casual-cellphone-1289898.jpg">
                                <h3 style="color:#ffd700;padding-top: 20px"> Beginners </h3>
                                <h5>Beginners</h5>
                                <p class="lead"> 
                                    This team starts the journey of programming with us, they get full free online courses and tasks that makes them better.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end section our team-->

        <!--  -->

        <!--Start Testimonials-->
        <div id="carousel" class="carousel slide scroll" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="over-lay">
                        <div class="admain-info">
                            <img src="img/testimonals/a1.png" alt="...">
                            <h4 class="admain-fname h3">Moe</h4>
                            <p class="info">
                                the Creator of the Developers lounge, current President. He manages everything:     Projects, Gigs, and Community’s work. 
                            </p>
                        </div>
                    </div>
                     <img src="img/ai-codes-coding-97077.jpg"  width="100%"alt="..."> 
                </div>
                <!-- <div class="carousel-item">
                    <div class="over-lay">
                        <div class="admain-info">
                            <img src="img/testimonals/a2.png" alt="...">
                            <h4 class="admain-fname h3">Ola</h4>
                            <p class="info">
                                Front-End web developer, She’s the head of ideas, she receives all new ideas and transfer them into work.
                            </p>
                        </div>
                    </div>
                    <img src="img/ai-codes-coding-97077.jpg"  width="100%"alt="...">  
                </div> -->
                <div class="carousel-item">
                    <div class="over-lay">
                        <div class="admain-info">
                            <img src="img/testimonals/a1.png" alt="...">
                            <h4 class="admain-fname h3">ameer</h4>
                            <p class="info">
                                Self-Employed Back-End Web Developer. He’s the Co-Founder of Developers Lounge, he runs most of the work.
                            </p>
                        </div>
                    </div>
                    <img src="img/ai-codes-coding-97077.jpg"  width="100%"alt="..."> 
                </div>

                <!-- the indecators for the carousel -->
                <div class="thumbnails">
                    <div class="admain admain-1" data-target="#carousel" data-slide-to="0">
                        <img src="img/testimonals/a1.png" alt="...">
                        <div class="admain-info">
                            <span class="admain-name">mohamed alaa</span>
                            <span class="developer">Founder</span>
                        </div>
                    </div>
                    <div class="admain admain-2" data-target="#carousel" data-slide-to="1">
                        <img src="img/testimonals/a1.png" alt="...">
                        <div class="admain-info">
                            <span class="admain-name">Ameer Ahmed</span>
                            <span class="developer">Co-Founder</span>
                        </div>
                    </div>
                    <!-- <div class="admain admain-3" data-target="#carousel" data-slide-to="2">
                        <img src="img/testimonals/a1.png" alt="...">
                        <div class="admain-info" >
                            <span class="admain-name">OLA</span>
                            <span class="developer">Front-End Web Developer</span>
                        </div>        
                    </div> -->
                </div>
            </div>
        </div>
        <!--End Testimonials-->

        <!--Start Skills-->
        <section class="skill" id="about">
            <header class="text-center">
                <h1>  our <span> skills </span> </h1>
            </header>
            <div>
                <section class="container">
                    <div class="row">
                        <div class="prog col-md-6">
                            <div class="skills-progress  col">
                                <div class="progress">
                                    <div class="progress-bar progress-bar-warning progress-bar-striped active"  role="progressbar"   aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:90%">
                                        Front-End
                                    </div>
                                </div>
                            </div>
                            <div class="skills-progress col">
                                <div class="progress">
                                    <div class="progress-bar progress-bar-success progress-bar-striped active"  role="progressbar"   aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:80%">
                                        Back-End
                                    </div>
                                </div>
                            </div>
                            <div class="skills-progress col">
                                <div class="progress">
                                    <div class="progress-bar progress-bar-info progress-bar-striped active"  role="progressbar"   aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:20%">
                                        Marketing
                                    </div>
                                </div>
                            </div>
                            <div class="skills-progress col">
                                <div class="progress">
                                    <div class="progress-bar progress-bar-danger progress-bar-striped active"  role="progressbar"   aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:80%">
                                        PhotoShop
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="parag col-md-6">
                            <h2> skills the team </h2>
                            <p class="lead">
                                We are specialised design and development team about web design and creating digital ideas, <span></span>
                            </p>
                            <button type="button" class="btn btn-danger"> read more</button>
                        </div>
                    </div>      
                </section>
            </div>
        </section>
            <!--End Skills--> 

<!-- Start of our projects-->

        <section style="background-image:url(bacc.jpg)" class="landing">
        <div class="landing-inner">
            <p>Our Projects Showcase</p>
            <h1>Coming Soon</h1>
            <div class="countdown"></div>
        </div>
        </section>

<!--End of our projects-->

        <!--Start Contact Us-->
        

        <!--Start Footer-->
        <footer>
            <div class="text-center">
                <h3>copy right &copy; Developer Lounge all right reserved</h3>
                <p> Created by: <span> Developer Lounge</span> Family </p>
            </div>
        </footer>
        <!--End Footer-->




        <script src="pages/js/jquery-3.3.1.min.js" ></script>
        <script src="pages/js/popper.min.js"></script>
        <script src="pages/js/bootstrap.min.js"></script>
        <script src="pages/js/wow.min.js"></script>
        <script src="pages/js/file.js"></script>    
        <script src="pages/js/puling.js"></script> 
        <script src="pages/js/jquery.countTo.js"></script>
        <script>
            new WOW().init();
        </script>
        <script src="pages/js/jquery.nicescroll.min.js"></script>

        <script>
            //nicescroll .JQUERY.nicescroll.js
            $(function() {
                var nice = $("html").niceScroll({cursorcolor:"black",cursorwidth:"8px",cursorborder:"1px solid black",scrollspeed:"20"}); 
            });
        </script>

        <div class="loading-overlay">
            <div class="loader">Loading...</div>
        </div>

        <script>
            $(window).on("load",function(){
                $('.loading-overlay .loader').fadeOut(2000,function(){
                    $('body').css('overflow','auto');
                    $(this).parent().fadeOut(3000,function(){
                        $(this).remove();
                    });
                });
                //$('.loading-overlay').fadeOut(2000);
            });
            const countdown = document.querySelector('.countdown');

// Set Launch Date (ms)
const launchDate = new Date('Jan 1, 2019 13:00:00').getTime();

// Update every second
const intvl = setInterval(() => {
  // Get todays date and time (ms)
  const now = new Date().getTime();

  // Distance from now and the launch date (ms)
  const distance = launchDate - now;

  // Time calculation
  const days = Math.floor(distance / (1000 * 60 * 60 * 24));
  const hours = Math.floor(
    (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
  );
  const mins = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display result
  countdown.innerHTML = `
  <div>${days}<span>Days</span></div> 
  <div>${hours}<span>Hours</span></div>
  <div>${mins}<span>Minutes</span></div>
  <div>${seconds}<span>Seconds</span></div>
  `;

  // If launch date is reached
  if (distance < 0) {
    // Stop countdown
    clearInterval(intvl);
    // Style and output text
    countdown.style.color = '#17a2b8';
    countdown.innerHTML = 'Launched!';
  }
}, 1000);

        </script>

    </body>
</html>
