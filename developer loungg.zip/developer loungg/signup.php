<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>developers loung</title>
        <link rel="stylesheet"  href="pages/css/bootstrap.min.css">
        <link rel="stylesheet"  href="pages/css/animate.css">
        <link rel="stylesheet"  href="pages/css/hover.css">
        <link rel="stylesheet"  href="pages/css/font-awesome.min.css">
        <link rel="stylesheet"  href="pages/css/main.css">
</head>
<body>
     <!--Start Contact Us-->
     <section id="contact" class="contact text-center scroll">
            <div class="text">
                <div class="col-xs-12">
                    <h1> Sign up or Join us!<i class= "fa fa-phone"></i>
                    <p class="lead"> Sign up to contact us or place an order, or join us to be a part of Developers Lounge</p></h1>     
                </div>
            </div>
            <div class="sgin">
                <form method="post" action="SignUpProcess.php">
                    <div class="col-sm-3">
                        <legend> Sign up  </legend>
                        
                    </div>
                  
                    <div class="col-sm-10">
                    <?php if($_GET){echo "<spam style='color:red;'>".$_GET['user']."</spam>" ;} ?>
                        <input type="text" class="form-control" id="fname" name="name" placeholder="Your Name" required>
                    </div>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="lname" name="email" placeholder="Email Address" required>
                    </div>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="tele" name="password" placeholder="Your Password" required>
                    </div>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="city" name="city" placeholder="Country">
                    </div>
                    <div class="col-sm-10">
                        <button type="submit"  onclick="valid()" class="btn btn-primary btn-lg">
                            Sgin up
                        </button>
                    </div>  
                </form> 
            </div>
        </section>
        <!--End Contact Us-->
          
        <!--Start Footer-->
        <footer>
            <div class="text-center">
                <h3>copy right &copy; Developer Lounge all right reserved</h3>
                <p> Created by: <span> Developer Lounge</span> Family </p>
            </div>
        </footer>
        <!--End Footer-->




        <script src="pages/js/jquery-3.3.1.min.js" ></script>
        <script src="pages/js/popper.min.js"></script>
        <script src="pages/js/bootstrap.min.js"></script>
        <script src="pages/js/wow.min.js"></script>
        <script src="pages/js/file.js"></script>    
        <script src="pages/js/puling.js"></script> 
        <script src="pages/js/jquery.countTo.js"></script>
        <script>
            new WOW().init();
        </script>
        <script src="pages/js/jquery.nicescroll.min.js"></script>

        <script>
            //nicescroll .JQUERY.nicescroll.js
            $(function() {
                var nice = $("html").niceScroll({cursorcolor:"black",cursorwidth:"8px",cursorborder:"1px solid black",scrollspeed:"20"}); 
            });
        </script>

        <div class="loading-overlay">
            <div class="loader">Loading...</div>
        </div>

        <script>
            $(window).on("load",function(){
                $('.loading-overlay .loader').fadeOut(2000,function(){
                    $('body').css('overflow','auto');
                    $(this).parent().fadeOut(3000,function(){
                        $(this).remove();
                    });
                });
                //$('.loading-overlay').fadeOut(2000);
            });
            const countdown = document.querySelector('.countdown');

// Set Launch Date (ms)
const launchDate = new Date('Jan 1, 2019 13:00:00').getTime();

// Update every second
const intvl = setInterval(() => {
  // Get todays date and time (ms)
  const now = new Date().getTime();

  // Distance from now and the launch date (ms)
  const distance = launchDate - now;

  // Time calculation
  const days = Math.floor(distance / (1000 * 60 * 60 * 24));
  const hours = Math.floor(
    (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
  );
  const mins = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display result
  countdown.innerHTML = `
  <div>${days}<span>Days</span></div> 
  <div>${hours}<span>Hours</span></div>
  <div>${mins}<span>Minutes</span></div>
  <div>${seconds}<span>Seconds</span></div>
  `;

  // If launch date is reached
  if (distance < 0) {
    // Stop countdown
    clearInterval(intvl);
    // Style and output text
    countdown.style.color = '#17a2b8';
    countdown.innerHTML = 'Launched!';
  }
}, 1000);

        </script>

</body>
</html>