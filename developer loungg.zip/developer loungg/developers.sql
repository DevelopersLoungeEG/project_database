-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 01 نوفمبر 2018 الساعة 08:38
-- إصدار الخادم: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `developers`
--

-- --------------------------------------------------------

--
-- بنية الجدول `projects`
--

CREATE TABLE `projects` (
  `images` varchar(64) NOT NULL,
  `like` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `projects`
--

INSERT INTO `projects` (`images`, `like`) VALUES
('', 41),
('', 0),
('', 0),
('', 0),
('', 0),
('', 40),
('', 0),
('', 0),
('', 0),
('', 0),
('', 41),
('', 0),
('', 0),
('', 0),
('', 0),
('', 40),
('', 0),
('', 0),
('', 0),
('', 0),
('', 41),
('', 0),
('', 0),
('', 0),
('', 0),
('', 40),
('', 0),
('', 0),
('', 0),
('', 0),
('', 0),
('', 0),
('', 0),
('', 0),
('', 0),
('', 0);

-- --------------------------------------------------------

--
-- بنية الجدول `useraccount`
--

CREATE TABLE `useraccount` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `city` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `useraccount`
--

INSERT INTO `useraccount` (`id`, `name`, `email`, `password`, `city`) VALUES
(1, '', 'now@gmail.com', '123', ''),
(2, '', 'hello@gmail.com', '123', ''),
(3, 'true', 'true@gmail.com', 'true', ''),
(4, '', '3@gmail.com', 'pdf', ''),
(5, 'path', 'path@gmail.com', 'path', 'path'),
(6, 'beet', 'teen@gmail.com', 'teen', 'beet');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `useraccount`
--
ALTER TABLE `useraccount`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `useraccount`
--
ALTER TABLE `useraccount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
